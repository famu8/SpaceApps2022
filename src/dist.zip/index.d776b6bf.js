function reset() {
    location.reload();
}
var selectedYear;
var selectedSeason;
function getSelectedYearSeason() {
    selectedYear = document.getElementById("selectYears").value;
    selectedSeason = document.getElementById("selectSeason").value;
    console.log("a\xf1o seleccionado", selectedYear);
    console.log("season seleccionado", selectedSeason);
}

//# sourceMappingURL=index.d776b6bf.js.map
